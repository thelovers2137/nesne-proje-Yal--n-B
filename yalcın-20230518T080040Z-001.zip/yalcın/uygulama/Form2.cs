﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace uygulama
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnekle_Click(object sender, EventArgs e)
        {
            string isim = txtad.Text;
            string soyisim = txtsoyad.Text;
            string numara = txtno.Text;

            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=verilerim.mdb;Persist Security Info=False;";
            OleDbConnection connection = new OleDbConnection(connectionString);
            connection.Open();

            string insertQuery = "INSERT INTO bilgiler (isim, soyisim, numara) VALUES (@isim, @soyisim, @numara)";
            OleDbCommand insertCommand = new OleDbCommand(insertQuery, connection);
            insertCommand.Parameters.AddWithValue("@isim", isim);
            insertCommand.Parameters.AddWithValue("@soyisim", soyisim);
            insertCommand.Parameters.AddWithValue("@numara", numara);
            insertCommand.ExecuteNonQuery();

            connection.Close();

            MessageBox.Show("Kayıt başarıyla eklendi!");

           
            txtad.Text = "";
            txtsoyad.Text = "";
            txtno.Text = "";
        }
    }
}

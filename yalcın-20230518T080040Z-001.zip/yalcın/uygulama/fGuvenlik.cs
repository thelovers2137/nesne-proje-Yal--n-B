﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace uygulama
{
    public partial class fGuvenlik : Form
    {
        public fGuvenlik()
        {
            InitializeComponent();
        }
        OleDbConnection con;
        OleDbCommand cmd;
        OleDbDataReader dr;
        private void btGiris_Click(object sender, EventArgs e)
        {
            string kulllaniciAdi = tbKullaniciAdi.Text;
            string sifre = tbSifre.Text;
            con = new OleDbConnection("Provider=Microsoft.ACE.Oledb.12.0;Data Source=verilerim.mdb");
            cmd = new OleDbCommand();
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "SELECT * FROM guvenlik where kullaniciadi='" + kulllaniciAdi + "' AND sifre='" + sifre + "'";
            dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                frmAna f2 = new frmAna();
                f2.Show();
                this.Visible = false;
            }
            else
            {
                MessageBox.Show("Kullanıcı adı ya da şifre yanlış");
            }

            con.Close();
        }

        private void btIptal_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

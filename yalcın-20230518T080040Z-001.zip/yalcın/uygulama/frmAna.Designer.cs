﻿namespace uygulama
{
    partial class frmAna
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAna));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btKitapEkle = new System.Windows.Forms.Button();
            this.btTurEkle = new System.Windows.Forms.Button();
            this.btOduncVer = new System.Windows.Forms.Button();
            this.btYayinEviEkle = new System.Windows.Forms.Button();
            this.btTeslimAl = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.btKitapEkle);
            this.groupBox1.Controls.Add(this.btTurEkle);
            this.groupBox1.Controls.Add(this.btOduncVer);
            this.groupBox1.Controls.Add(this.btYayinEviEkle);
            this.groupBox1.Controls.Add(this.btTeslimAl);
            this.groupBox1.Font = new System.Drawing.Font("Perpetua Titling MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(2, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(156, 321);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "İşlemler";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.Image = global::uygulama.Properties.Resources.User_Manual_80_icon_icons_com_57245;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.button1.Location = new System.Drawing.Point(10, 277);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(125, 38);
            this.button1.TabIndex = 5;
            this.button1.Text = "Bilgiler";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btKitapEkle
            // 
            this.btKitapEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btKitapEkle.Image = global::uygulama.Properties.Resources.add_book_icon_icons_com_71795;
            this.btKitapEkle.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btKitapEkle.Location = new System.Drawing.Point(10, 29);
            this.btKitapEkle.Name = "btKitapEkle";
            this.btKitapEkle.Size = new System.Drawing.Size(125, 38);
            this.btKitapEkle.TabIndex = 0;
            this.btKitapEkle.Text = "      Kitap Ekle";
            this.btKitapEkle.UseVisualStyleBackColor = true;
            this.btKitapEkle.Click += new System.EventHandler(this.btKitapEkle_Click);
            // 
            // btTurEkle
            // 
            this.btTurEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btTurEkle.Image = global::uygulama.Properties.Resources.category_add_button_icon_icons_com_71724__2_;
            this.btTurEkle.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btTurEkle.Location = new System.Drawing.Point(10, 233);
            this.btTurEkle.Name = "btTurEkle";
            this.btTurEkle.Size = new System.Drawing.Size(125, 38);
            this.btTurEkle.TabIndex = 4;
            this.btTurEkle.Text = "Tür Ekle";
            this.btTurEkle.UseVisualStyleBackColor = true;
            this.btTurEkle.Click += new System.EventHandler(this.btTurEkle_Click);
            // 
            // btOduncVer
            // 
            this.btOduncVer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btOduncVer.Image = global::uygulama.Properties.Resources.handover;
            this.btOduncVer.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btOduncVer.Location = new System.Drawing.Point(10, 73);
            this.btOduncVer.Name = "btOduncVer";
            this.btOduncVer.Size = new System.Drawing.Size(125, 38);
            this.btOduncVer.TabIndex = 1;
            this.btOduncVer.Text = "      Ödünç Ver";
            this.btOduncVer.UseVisualStyleBackColor = true;
            this.btOduncVer.Click += new System.EventHandler(this.btOduncVer_Click);
            // 
            // btYayinEviEkle
            // 
            this.btYayinEviEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btYayinEviEkle.Image = global::uygulama.Properties.Resources.book__1_1;
            this.btYayinEviEkle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btYayinEviEkle.Location = new System.Drawing.Point(10, 161);
            this.btYayinEviEkle.Name = "btYayinEviEkle";
            this.btYayinEviEkle.Size = new System.Drawing.Size(125, 66);
            this.btYayinEviEkle.TabIndex = 3;
            this.btYayinEviEkle.Text = "     Yayınevi Ekle";
            this.btYayinEviEkle.UseVisualStyleBackColor = true;
            this.btYayinEviEkle.Click += new System.EventHandler(this.btYayinEviEkle_Click);
            // 
            // btTeslimAl
            // 
            this.btTeslimAl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btTeslimAl.Image = global::uygulama.Properties.Resources.back_2_icon_icons_com_63360__1_;
            this.btTeslimAl.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btTeslimAl.Location = new System.Drawing.Point(10, 117);
            this.btTeslimAl.Name = "btTeslimAl";
            this.btTeslimAl.Size = new System.Drawing.Size(125, 38);
            this.btTeslimAl.TabIndex = 2;
            this.btTeslimAl.Text = "Teslim Al";
            this.btTeslimAl.UseVisualStyleBackColor = true;
            this.btTeslimAl.Click += new System.EventHandler(this.btTeslimAl_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Location = new System.Drawing.Point(164, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(690, 321);
            this.panel1.TabIndex = 6;
            // 
            // frmAna
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(863, 339);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.Name = "frmAna";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AnaBölüm";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btKitapEkle;
        private System.Windows.Forms.Button btOduncVer;
        private System.Windows.Forms.Button btTeslimAl;
        private System.Windows.Forms.Button btYayinEviEkle;
        private System.Windows.Forms.Button btTurEkle;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uygulama
{
    public partial class frmAna : Form
    {
        public frmAna()
        {
            InitializeComponent();
        }
        frmKitapEkle f2g = new frmKitapEkle();
        private void btKitapEkle_Click(object sender, EventArgs e)
        {
            b.Visible = false;
            f2a.Visible = false;
            f2b.Visible = false;
            f2c.Visible = false;
            f2e.Visible = false;
            f2g.MdiParent = this;
            f2g.FormBorderStyle = FormBorderStyle.None;
            panel1.Controls.Add(f2g);
            f2g.Show();
        }
        frmOduncVer f2e = new frmOduncVer();
        private void btOduncVer_Click(object sender, EventArgs e)
        {
            b.Visible = false;
            f2a.Visible = false;
            f2b.Visible = false;
            f2c.Visible = false;
            f2g.Visible = false;
            f2e.MdiParent = this;
            f2e.FormBorderStyle = FormBorderStyle.None;
            panel1.Controls.Add(f2e);
            f2e.Show();
        }
        frmTeslimAl f2c = new frmTeslimAl();
        private void btTeslimAl_Click(object sender, EventArgs e)
        {
            b.Visible = false;
            f2a.Visible = false;
            f2b.Visible = false;
            f2e.Visible = false;
            f2g.Visible = false;
            f2c.MdiParent = this;
            f2c.FormBorderStyle = FormBorderStyle.None;
            panel1.Controls.Add(f2c);
            f2c.Show();
        }
        frmTurEkle f2b = new frmTurEkle();
        private void btTurEkle_Click(object sender, EventArgs e)
        {
            b.Visible = false;
            f2a.Visible = false;
            f2c.Visible = false;
            f2g.Visible = false;
            f2e.Visible = false;
            f2b.MdiParent = this;
            f2b.FormBorderStyle = FormBorderStyle.None;
            panel1.Controls.Add(f2b);
            f2b.Show();
            
        }
        frmYayinEviEkle f2a = new frmYayinEviEkle();
        private void btYayinEviEkle_Click(object sender, EventArgs e)
        {
            b.Visible = false;
            f2b.Visible = false;
            f2c.Visible = false;
            f2e.Visible = false;
            f2g.Visible = false;
            f2a.MdiParent = this;
            f2a.FormBorderStyle = FormBorderStyle.None;
            panel1.Controls.Add(f2a);
            f2a.Show();

        }
        bilgiler b = new bilgiler();
        private void button1_Click(object sender, EventArgs e)
        {
            f2b.Visible = false;
            f2c.Visible = false;
            f2e.Visible = false;
            f2g.Visible = false;
            f2a.Visible = false;
            b.MdiParent = this;
            b.FormBorderStyle = FormBorderStyle.None;
            panel1.Controls.Add(b);
            b.Show();
        }
    }
}

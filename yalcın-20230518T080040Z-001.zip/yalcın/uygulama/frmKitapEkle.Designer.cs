﻿namespace uygulama
{
    partial class frmKitapEkle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmKitapEkle));
            this.btKaydet = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tbAdi = new System.Windows.Forms.TextBox();
            this.gvKitaplar = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tbBarkodu = new System.Windows.Forms.TextBox();
            this.tbYazari = new System.Windows.Forms.TextBox();
            this.tbSayfaSayisi = new System.Windows.Forms.TextBox();
            this.cbYayinEvi = new System.Windows.Forms.ComboBox();
            this.cmsYayinEvi = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.yayıneviEkleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cbTuru = new System.Windows.Forms.ComboBox();
            this.cmsTur = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.türEkleToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.gvKitaplar)).BeginInit();
            this.cmsYayinEvi.SuspendLayout();
            this.cmsTur.SuspendLayout();
            this.SuspendLayout();
            // 
            // btKaydet
            // 
            this.btKaydet.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btKaydet.Location = new System.Drawing.Point(12, 220);
            this.btKaydet.Name = "btKaydet";
            this.btKaydet.Size = new System.Drawing.Size(284, 43);
            this.btKaydet.TabIndex = 0;
            this.btKaydet.Text = "Kaydet";
            this.btKaydet.UseVisualStyleBackColor = true;
            this.btKaydet.Click += new System.EventHandler(this.btKaydet_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(9, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "Kitap Adı:";
            // 
            // tbAdi
            // 
            this.tbAdi.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbAdi.Location = new System.Drawing.Point(136, 19);
            this.tbAdi.Name = "tbAdi";
            this.tbAdi.Size = new System.Drawing.Size(160, 27);
            this.tbAdi.TabIndex = 2;
            // 
            // gvKitaplar
            // 
            this.gvKitaplar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvKitaplar.Dock = System.Windows.Forms.DockStyle.Right;
            this.gvKitaplar.Location = new System.Drawing.Point(302, 0);
            this.gvKitaplar.Name = "gvKitaplar";
            this.gvKitaplar.Size = new System.Drawing.Size(491, 271);
            this.gvKitaplar.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(9, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 18);
            this.label2.TabIndex = 4;
            this.label2.Text = "Barkodu:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(9, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 18);
            this.label3.TabIndex = 5;
            this.label3.Text = "Yayın Evi:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(9, 118);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 18);
            this.label4.TabIndex = 6;
            this.label4.Text = "Yazarı:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(9, 150);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 18);
            this.label5.TabIndex = 7;
            this.label5.Text = "Türü:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(9, 182);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(107, 18);
            this.label6.TabIndex = 8;
            this.label6.Text = "Sayfa Sayısı";
            // 
            // tbBarkodu
            // 
            this.tbBarkodu.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbBarkodu.Location = new System.Drawing.Point(136, 50);
            this.tbBarkodu.Name = "tbBarkodu";
            this.tbBarkodu.Size = new System.Drawing.Size(160, 27);
            this.tbBarkodu.TabIndex = 9;
            // 
            // tbYazari
            // 
            this.tbYazari.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbYazari.Location = new System.Drawing.Point(136, 113);
            this.tbYazari.Name = "tbYazari";
            this.tbYazari.Size = new System.Drawing.Size(160, 27);
            this.tbYazari.TabIndex = 10;
            // 
            // tbSayfaSayisi
            // 
            this.tbSayfaSayisi.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbSayfaSayisi.Location = new System.Drawing.Point(136, 176);
            this.tbSayfaSayisi.Name = "tbSayfaSayisi";
            this.tbSayfaSayisi.Size = new System.Drawing.Size(160, 27);
            this.tbSayfaSayisi.TabIndex = 12;
            // 
            // cbYayinEvi
            // 
            this.cbYayinEvi.ContextMenuStrip = this.cmsYayinEvi;
            this.cbYayinEvi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cbYayinEvi.FormattingEnabled = true;
            this.cbYayinEvi.Location = new System.Drawing.Point(136, 81);
            this.cbYayinEvi.Name = "cbYayinEvi";
            this.cbYayinEvi.Size = new System.Drawing.Size(160, 28);
            this.cbYayinEvi.TabIndex = 13;
            // 
            // cmsYayinEvi
            // 
            this.cmsYayinEvi.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yayıneviEkleToolStripMenuItem});
            this.cmsYayinEvi.Name = "cmsYayinEvi";
            this.cmsYayinEvi.Size = new System.Drawing.Size(142, 26);
            // 
            // yayıneviEkleToolStripMenuItem
            // 
            this.yayıneviEkleToolStripMenuItem.Name = "yayıneviEkleToolStripMenuItem";
            this.yayıneviEkleToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.yayıneviEkleToolStripMenuItem.Text = "Yayınevi Ekle";
            this.yayıneviEkleToolStripMenuItem.Click += new System.EventHandler(this.yayıneviEkleToolStripMenuItem_Click);
            // 
            // cbTuru
            // 
            this.cbTuru.ContextMenuStrip = this.cmsTur;
            this.cbTuru.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cbTuru.FormattingEnabled = true;
            this.cbTuru.Location = new System.Drawing.Point(136, 144);
            this.cbTuru.Name = "cbTuru";
            this.cbTuru.Size = new System.Drawing.Size(160, 28);
            this.cbTuru.TabIndex = 14;
            // 
            // cmsTur
            // 
            this.cmsTur.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.türEkleToolStripMenuItem1});
            this.cmsTur.Name = "cmsYayinEvi";
            this.cmsTur.Size = new System.Drawing.Size(116, 26);
            // 
            // türEkleToolStripMenuItem1
            // 
            this.türEkleToolStripMenuItem1.Name = "türEkleToolStripMenuItem1";
            this.türEkleToolStripMenuItem1.Size = new System.Drawing.Size(115, 22);
            this.türEkleToolStripMenuItem1.Text = "Tür Ekle";
            this.türEkleToolStripMenuItem1.Click += new System.EventHandler(this.türEkleToolStripMenuItem1_Click);
            // 
            // frmKitapEkle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(793, 271);
            this.Controls.Add(this.cbTuru);
            this.Controls.Add(this.cbYayinEvi);
            this.Controls.Add(this.tbSayfaSayisi);
            this.Controls.Add(this.tbYazari);
            this.Controls.Add(this.tbBarkodu);
            this.Controls.Add(this.tbAdi);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.gvKitaplar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btKaydet);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmKitapEkle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kitap Ekle";
            this.Load += new System.EventHandler(this.frmKitapEkle_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gvKitaplar)).EndInit();
            this.cmsYayinEvi.ResumeLayout(false);
            this.cmsTur.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btKaydet;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbAdi;
        private System.Windows.Forms.DataGridView gvKitaplar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbBarkodu;
        private System.Windows.Forms.TextBox tbYazari;
        private System.Windows.Forms.TextBox tbSayfaSayisi;
        private System.Windows.Forms.ComboBox cbYayinEvi;
        private System.Windows.Forms.ComboBox cbTuru;
        private System.Windows.Forms.ContextMenuStrip cmsYayinEvi;
        private System.Windows.Forms.ToolStripMenuItem yayıneviEkleToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip cmsTur;
        private System.Windows.Forms.ToolStripMenuItem türEkleToolStripMenuItem1;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uygulama
{
    public partial class frmKitapEkle : Form
    {
        public frmKitapEkle()
        {
            InitializeComponent();
        }

        private void frmKitapEkle_Load(object sender, EventArgs e)
        {
            yayinEviYukle();
            turuYukle();
            listele();
        }


        OleDbConnection con;
        OleDbDataAdapter da;
        OleDbCommand cmd;


        private void yayinEviYukle()
        {
            try
            {

                con = new OleDbConnection("Provider=Microsoft.ACE.Oledb.12.0;Data Source=verilerim.mdb");

                con.Open();

                da = new OleDbDataAdapter("Select yayinEviAdi from yayinEvi", con);
                DataSet ds = new DataSet();

                da.Fill(ds);
                cbYayinEvi .DataSource = ds.Tables[0];
                cbYayinEvi.DisplayMember = "yayinEviAdi";
                cbYayinEvi.ValueMember = "yayinEviAdi";

                
                con.Close();
            }
            catch (Exception w)
            {

         
            }
        }

     
        
        
       void turuYukle()
        {
            try
            {

                con = new OleDbConnection("Provider=Microsoft.ACE.Oledb.12.0;Data Source=verilerim.mdb");

                con.Open();

                da = new OleDbDataAdapter("Select kitapTuru from kitapTuru", con);
                DataSet ds = new DataSet();

                da.Fill(ds);
                cbTuru.DataSource = ds.Tables[0];
                cbTuru.DisplayMember = "kitapTuru";
                cbTuru.ValueMember = "kitapTuru";


                con.Close();
            }
            catch (Exception w)
            {


            }
        }

        private void btKaydet_Click(object sender, EventArgs e)
        {
            try
            {
                con = new OleDbConnection("Provider=Microsoft.ACE.Oledb.12.0;Data Source=verilerim.mdb");
                cmd = new OleDbCommand();
                con.Open();
                cmd.Connection = con;
                cmd.CommandText = "insert into kitaplar (adi, barkodu, yayinevi,yazari, turu, sayfaSayisi) values ('" + tbAdi.Text + "','"+tbBarkodu.Text+ "','"+cbYayinEvi.SelectedValue + "','" + tbYazari.Text + "','" + cbTuru.SelectedValue + "'," + tbSayfaSayisi.Text + ")";
                cmd.ExecuteNonQuery();
                tbAdi.Text = null;
                tbBarkodu.Text = null;
                tbYazari.Text = null;
                tbSayfaSayisi.Text = null;

                con.Close();
                listele();
            }
            catch (Exception w)
            {

                throw;
            }
        }

        private void listele()
        {

            try
            {
                con = new OleDbConnection("Provider=Microsoft.ACE.Oledb.12.0;Data Source=verilerim.mdb");
                con.Open();
                DataSet ds = new DataSet();
                da = new OleDbDataAdapter("Select adi, barkodu, yayinevi,yazari, turu, sayfaSayisi from kitaplar", con);
                da.Fill(ds);
                gvKitaplar.DataSource = ds.Tables[0];
                con.Close();
            }
            catch (Exception w)
            {


            }

        }

        private void türEkleToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmTurEkle f2 = new frmTurEkle();
            f2.ShowDialog();
            turuYukle();
        }

        private void yayıneviEkleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmYayinEviEkle f2 = new frmYayinEviEkle();
            f2.ShowDialog();
            yayinEviYukle();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uygulama
{
    public partial class frmOduncVer : Form
    {
        public frmOduncVer()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int ogrenciNo = (int)comboBox1.SelectedValue;
            string ogrenciAdi = comboBox1.Text;
            string kitapNo = (string)comboBox2.SelectedValue;
            string kitapAdi = comboBox2.Text;

            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=verilerim.mdb;Persist Security Info=False;";
            OleDbConnection connection = new OleDbConnection(connectionString);
            connection.Open();
            string seciliKitapAdi = comboBox2.Text;

            string query = "SELECT durum FROM kitaplar WHERE adi = @adi";
            OleDbCommand command = new OleDbCommand(query, connection);
            command.Parameters.AddWithValue("@adi", seciliKitapAdi);

            object result = command.ExecuteScalar();
            string stokDurumu = result != null ? result.ToString() : null;

            if (stokDurumu == "verildi")
            {
                MessageBox.Show("Bu kitap şu anda stokta değil.", "Stokta Yok", MessageBoxButtons.OK, MessageBoxIcon.Information);
                // Kitabın verilme işlemi yapılamaz, gerekli işlemleri buraya ekleyin
            }
            else
            {
                string updateQuery = "UPDATE kitaplar SET durum='verildi' WHERE adi = @adi";
                OleDbCommand updateCommand = new OleDbCommand(updateQuery, connection);
                updateCommand.Parameters.AddWithValue("@adi", seciliKitapAdi);
                int affectedRows = updateCommand.ExecuteNonQuery();

                // Bilgiler tablosunda ilgili öğrencinin aldigikitap sütununu güncelle
                string updateBilgilerQuery = "UPDATE bilgiler SET aldigikitap = @adi WHERE isim = @isim";
                OleDbCommand updateBilgilerCommand = new OleDbCommand(updateBilgilerQuery, connection);
                updateBilgilerCommand.Parameters.AddWithValue("@adi", kitapAdi);
                updateBilgilerCommand.Parameters.AddWithValue("@isim", ogrenciAdi);
                int affectedRows2 = updateBilgilerCommand.ExecuteNonQuery();

                if (affectedRows == 1 && affectedRows2 == 1)
                {
                    MessageBox.Show(kitapAdi + " kitabı ödünç verildi.");
                }
                else
                {
                    MessageBox.Show(kitapAdi + " kitabı ödünç verildi.");
                }
}
        }

        private void frmOduncVer_Load(object sender, EventArgs e)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=verilerim.mdb;Persist Security Info=False;";
            OleDbConnection connection = new OleDbConnection(connectionString);
            connection.Open();

            string query = "SELECT * FROM bilgiler";
            OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);

            comboBox1.DataSource = dataTable;
            comboBox1.DisplayMember = "isim";
            comboBox1.ValueMember = "id";
            //combobox2 nin kodları
            connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=verilerim.mdb;Persist Security Info=False;";
            connection = new OleDbConnection(connectionString);
            connection.Open();

            query = "SELECT * FROM kitaplar";
            adapter = new OleDbDataAdapter(query, connection);
            dataTable = new DataTable();
            adapter.Fill(dataTable);

            comboBox2.DataSource = dataTable;
            comboBox2.DisplayMember = "adi";
            comboBox2.ValueMember = "barkodu";
        }
        Form2 uyeekle = new Form2();

        private void yeniKayıtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            uyeekle.Show();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            //
        }
    }
}

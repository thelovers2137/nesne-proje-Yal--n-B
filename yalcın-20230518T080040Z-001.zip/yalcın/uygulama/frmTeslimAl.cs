﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uygulama
{
    public partial class frmTeslimAl : Form
    {
        public frmTeslimAl()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int ogrenciNo = 0;
            string alinanKitap = "";

            // Öğrenci seçimini kontrol et
            if (comboBox1.SelectedItem != null && comboBox1.SelectedValue != null && int.TryParse(comboBox1.SelectedValue.ToString(), out ogrenciNo))
            {
                // Öğrenci numarası başarıyla alındı
            }
            else
            {
                MessageBox.Show("Geçersiz öğrenci seçimi.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            // Alınan kitap seçimini kontrol et
            if (comboBox2.SelectedItem != null)
            {
                alinanKitap = comboBox2.SelectedValue.ToString();
            }
            else
            {
                MessageBox.Show("Alınan kitap seçimi yapmadınız.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=verilerim.mdb;Persist Security Info=False;";
            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                connection.Open();

                // Alınan kitabı temizle
                string updateBilgilerQuery = "UPDATE bilgiler SET aldigikitap = NULL WHERE numara = @numara";
                using (OleDbCommand updateBilgilerCommand = new OleDbCommand(updateBilgilerQuery, connection))
                {
                    updateBilgilerCommand.Parameters.AddWithValue("@numara", ogrenciNo);
                    int affectedRows = updateBilgilerCommand.ExecuteNonQuery();

                    if (affectedRows == 1)
                    {
                        // Kitap durumunu temizle
                        string updateKitaplarQuery = "UPDATE kitaplar SET durum = NULL WHERE adi = @adi";
                        using (OleDbCommand updateKitaplarCommand = new OleDbCommand(updateKitaplarQuery, connection))
                        {
                            updateKitaplarCommand.Parameters.AddWithValue("@adi", alinanKitap);
                            int affectedRows2 = updateKitaplarCommand.ExecuteNonQuery();

                            if (affectedRows2 == 1)
                            {
                                MessageBox.Show(alinanKitap + " kitabının durumu temizlendi.", "Kitap Durumu Temizlendi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            else
                            {
                                MessageBox.Show("Kitap durumu temizlenirken bir hata oluştu.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Alınan kitap güncellenirken bir hata oluştu.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
        private void frmTeslimAl_Load(object sender, EventArgs e)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=verilerim.mdb;Persist Security Info=False;";
OleDbConnection connection = new OleDbConnection(connectionString);
connection.Open();

// comboBox1 için isimlerin verisini al
string selectIsimlerQuery = "SELECT isim FROM bilgiler";
OleDbCommand selectIsimlerCommand = new OleDbCommand(selectIsimlerQuery, connection);
OleDbDataReader isimlerReader = selectIsimlerCommand.ExecuteReader();

while (isimlerReader.Read())
{
    string isim = isimlerReader["isim"].ToString();
    comboBox1.Items.Add(isim);
}

isimlerReader.Close();

// comboBox2 için kitapların verisini al
string selectKitaplarQuery = "SELECT adi FROM kitaplar";
OleDbCommand selectKitaplarCommand = new OleDbCommand(selectKitaplarQuery, connection);
OleDbDataReader kitaplarReader = selectKitaplarCommand.ExecuteReader();

while (kitaplarReader.Read())
{
    string kitapAdi = kitaplarReader["adi"].ToString();
    comboBox2.Items.Add(kitapAdi);
}

kitaplarReader.Close();

connection.Close();
    }
}
}

﻿namespace uygulama
{
    partial class frmTurEkle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTurEkle));
            this.gvKitapTuru = new System.Windows.Forms.DataGridView();
            this.tbKitapTuru = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btKaydet = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gvKitapTuru)).BeginInit();
            this.SuspendLayout();
            // 
            // gvKitapTuru
            // 
            this.gvKitapTuru.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvKitapTuru.Dock = System.Windows.Forms.DockStyle.Right;
            this.gvKitapTuru.Location = new System.Drawing.Point(304, 0);
            this.gvKitapTuru.Name = "gvKitapTuru";
            this.gvKitapTuru.Size = new System.Drawing.Size(348, 271);
            this.gvKitapTuru.TabIndex = 22;
            // 
            // tbKitapTuru
            // 
            this.tbKitapTuru.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbKitapTuru.Location = new System.Drawing.Point(129, 19);
            this.tbKitapTuru.Name = "tbKitapTuru";
            this.tbKitapTuru.Size = new System.Drawing.Size(160, 27);
            this.tbKitapTuru.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(2, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 18);
            this.label1.TabIndex = 20;
            this.label1.Text = "Kitap Türü:";
            // 
            // btKaydet
            // 
            this.btKaydet.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btKaydet.Location = new System.Drawing.Point(5, 64);
            this.btKaydet.Name = "btKaydet";
            this.btKaydet.Size = new System.Drawing.Size(284, 43);
            this.btKaydet.TabIndex = 19;
            this.btKaydet.Text = "Kaydet";
            this.btKaydet.UseVisualStyleBackColor = true;
            this.btKaydet.Click += new System.EventHandler(this.btKaydet_Click);
            // 
            // frmTurEkle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(652, 271);
            this.Controls.Add(this.gvKitapTuru);
            this.Controls.Add(this.tbKitapTuru);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btKaydet);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmTurEkle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TurEkle";
            this.Load += new System.EventHandler(this.frmTurEkle_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gvKitapTuru)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView gvKitapTuru;
        private System.Windows.Forms.TextBox tbKitapTuru;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btKaydet;
    }
}
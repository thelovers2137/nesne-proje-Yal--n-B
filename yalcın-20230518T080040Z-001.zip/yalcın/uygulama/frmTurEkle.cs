﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace uygulama
{
    public partial class frmTurEkle : Form
    {
        public frmTurEkle()
        {
            InitializeComponent();
        }
        OleDbConnection con;
        OleDbDataAdapter da;
        OleDbCommand cmd;
        private void btKaydet_Click(object sender, EventArgs e)
        {

            try
            {
                con = new OleDbConnection("Provider=Microsoft.ACE.Oledb.12.0;Data Source=verilerim.mdb");
                cmd = new OleDbCommand();
                con.Open();
                cmd.Connection = con;
                cmd.CommandText = "insert into kitapTuru (kitapTuru) values ('" + tbKitapTuru.Text + "')";
                cmd.ExecuteNonQuery();
                tbKitapTuru.Text = null;
                con.Close();
                listele();
                //   MessageBox.Show("Yayınevi eklenmiştir", "BİLGİLENDİRME", MessageBoxButtons.OK, MessageBoxIcon.Information);


            }
            catch (Exception w)
            {


            }
        }
        private void listele()
        {

            try
            {
                con = new OleDbConnection("Provider=Microsoft.ACE.Oledb.12.0;Data Source=verilerim.mdb");
                con.Open();
                DataSet ds = new DataSet();
                da = new OleDbDataAdapter("Select kitapTuru from kitapTuru", con);
                da.Fill(ds);
                gvKitapTuru.DataSource = ds.Tables[0];
                con.Close();
            }
            catch (Exception w)
            {


            }

        }

        private void frmTurEkle_Load(object sender, EventArgs e)
        {
            try
            {
                listele();
            }
            catch (Exception w)
            {

                throw;
            }
        }
    }
}

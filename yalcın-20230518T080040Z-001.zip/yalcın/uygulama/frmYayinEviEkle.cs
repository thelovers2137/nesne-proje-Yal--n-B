﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uygulama
{
    public partial class frmYayinEviEkle : Form
    {
        public frmYayinEviEkle()
        {
            InitializeComponent();
        }
        OleDbConnection con;
        OleDbDataAdapter da;
        OleDbCommand cmd;
        private void btKaydet_Click(object sender, EventArgs e)
        {
            try
            {  con = new OleDbConnection("Provider=Microsoft.ACE.Oledb.12.0;Data Source=verilerim.mdb");
            cmd = new OleDbCommand();
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "insert into yayinEvi (yayinEviAdi) values ('" + tbYatineviAdi.Text + "')";
            cmd.ExecuteNonQuery();
            con.Close();
                listele();
         //   MessageBox.Show("Yayınevi eklenmiştir", "BİLGİLENDİRME", MessageBoxButtons.OK, MessageBoxIcon.Information);


            }
            catch (Exception w)
            {

          
            }
          
        }

        private void listele()
        {

            try
            {
                con = new OleDbConnection("Provider=Microsoft.ACE.Oledb.12.0;Data Source=verilerim.mdb"); 
                con.Open(); 
                DataSet ds = new DataSet(); 
                da = new OleDbDataAdapter("Select * from yayinEvi", con);
                da.Fill(ds);
                gvYayinEvi.DataSource = ds.Tables[0]; 
                con.Close();
            }
            catch (Exception w)
            {

         
            }

        }

        private void frmYayinEviEkle_Load(object sender, EventArgs e)
        {
            try
            {
                listele();
            }
            catch (Exception w)
            {

                throw;
            }
        }
    }
}

﻿namespace uygulama
{
    partial class fDatabinding
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbHedef = new System.Windows.Forms.TextBox();
            this.tbKaynak = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbHedef2 = new System.Windows.Forms.TextBox();
            this.tbKaynak2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // tbHedef
            // 
            this.tbHedef.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbHedef.Location = new System.Drawing.Point(184, 131);
            this.tbHedef.Name = "tbHedef";
            this.tbHedef.Size = new System.Drawing.Size(233, 38);
            this.tbHedef.TabIndex = 9;
            // 
            // tbKaynak
            // 
            this.tbKaynak.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbKaynak.Location = new System.Drawing.Point(184, 51);
            this.tbKaynak.Name = "tbKaynak";
            this.tbKaynak.Size = new System.Drawing.Size(233, 38);
            this.tbKaynak.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(63, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 31);
            this.label1.TabIndex = 10;
            this.label1.Text = "Kaynak";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(81, 138);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 31);
            this.label2.TabIndex = 11;
            this.label2.Text = "Hedef";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(320, 486);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 31);
            this.label3.TabIndex = 15;
            this.label3.Text = "Hedef";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(302, 399);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 31);
            this.label4.TabIndex = 14;
            this.label4.Text = "Kaynak";
            // 
            // tbHedef2
            // 
            this.tbHedef2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbHedef2.Location = new System.Drawing.Point(423, 479);
            this.tbHedef2.Name = "tbHedef2";
            this.tbHedef2.Size = new System.Drawing.Size(233, 38);
            this.tbHedef2.TabIndex = 13;
            // 
            // tbKaynak2
            // 
            this.tbKaynak2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbKaynak2.Location = new System.Drawing.Point(423, 399);
            this.tbKaynak2.Name = "tbKaynak2";
            this.tbKaynak2.Size = new System.Drawing.Size(233, 38);
            this.tbKaynak2.TabIndex = 12;
            this.tbKaynak2.TextChanged += new System.EventHandler(this.tbKaynak2_TextChanged);
            // 
            // fDatabinding
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1040, 638);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbHedef2);
            this.Controls.Add(this.tbKaynak2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbHedef);
            this.Controls.Add(this.tbKaynak);
            this.Name = "fDatabinding";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "fDatabinding";
            this.Load += new System.EventHandler(this.fDatabinding_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbHedef;
        private System.Windows.Forms.TextBox tbKaynak;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbHedef2;
        private System.Windows.Forms.TextBox tbKaynak2;
    }
}
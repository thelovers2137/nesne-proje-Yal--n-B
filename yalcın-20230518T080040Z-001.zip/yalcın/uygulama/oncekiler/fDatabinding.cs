﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uygulama
{
    public partial class fDatabinding : Form
    {
        public fDatabinding()
        {
            InitializeComponent();
        }

        private void fDatabinding_Load(object sender, EventArgs e)
        {
           Binding bagla = new Binding("Text", tbKaynak, "Text");
            tbHedef.DataBindings.Add(bagla);
     
    }

        private void tbKaynak2_TextChanged(object sender, EventArgs e)
        {
            tbHedef2.Text = tbKaynak2.Text; 
        }
    }
}

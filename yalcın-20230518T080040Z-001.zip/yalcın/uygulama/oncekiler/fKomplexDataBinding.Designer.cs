﻿namespace uygulama
{
    partial class fKomplexDataBinding
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbSoyisim = new System.Windows.Forms.TextBox();
            this.tbIsim = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbNumara = new System.Windows.Forms.TextBox();
            this.lbListe = new System.Windows.Forms.ListBox();
            this.btKaydet = new System.Windows.Forms.Button();
            this.btOrnek1 = new System.Windows.Forms.Button();
            this.btListeyiBosalt = new System.Windows.Forms.Button();
            this.btOrnek2 = new System.Windows.Forms.Button();
            this.cbIsim = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cbSoyisim = new System.Windows.Forms.ComboBox();
            this.cbNumara = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(29, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 31);
            this.label2.TabIndex = 15;
            this.label2.Text = "Soyisim";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(74, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 31);
            this.label1.TabIndex = 14;
            this.label1.Text = "İsim";
            // 
            // tbSoyisim
            // 
            this.tbSoyisim.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbSoyisim.Location = new System.Drawing.Point(155, 92);
            this.tbSoyisim.Name = "tbSoyisim";
            this.tbSoyisim.Size = new System.Drawing.Size(233, 38);
            this.tbSoyisim.TabIndex = 13;
            // 
            // tbIsim
            // 
            this.tbIsim.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbIsim.Location = new System.Drawing.Point(155, 36);
            this.tbIsim.Name = "tbIsim";
            this.tbIsim.Size = new System.Drawing.Size(233, 38);
            this.tbIsim.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(29, 151);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 31);
            this.label3.TabIndex = 17;
            this.label3.Text = "Numara";
            // 
            // tbNumara
            // 
            this.tbNumara.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbNumara.Location = new System.Drawing.Point(155, 148);
            this.tbNumara.Name = "tbNumara";
            this.tbNumara.Size = new System.Drawing.Size(233, 38);
            this.tbNumara.TabIndex = 16;
            // 
            // lbListe
            // 
            this.lbListe.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbListe.FormattingEnabled = true;
            this.lbListe.ItemHeight = 31;
            this.lbListe.Location = new System.Drawing.Point(769, 151);
            this.lbListe.Name = "lbListe";
            this.lbListe.Size = new System.Drawing.Size(320, 159);
            this.lbListe.TabIndex = 18;
            // 
            // btKaydet
            // 
            this.btKaydet.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btKaydet.Location = new System.Drawing.Point(35, 211);
            this.btKaydet.Name = "btKaydet";
            this.btKaydet.Size = new System.Drawing.Size(353, 48);
            this.btKaydet.TabIndex = 19;
            this.btKaydet.Text = "Kaydet";
            this.btKaydet.UseVisualStyleBackColor = true;
            this.btKaydet.Click += new System.EventHandler(this.btKaydet_Click);
            // 
            // btOrnek1
            // 
            this.btOrnek1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btOrnek1.Location = new System.Drawing.Point(769, 15);
            this.btOrnek1.Name = "btOrnek1";
            this.btOrnek1.Size = new System.Drawing.Size(320, 57);
            this.btOrnek1.TabIndex = 20;
            this.btOrnek1.Text = "Örnek 1.";
            this.btOrnek1.UseVisualStyleBackColor = true;
            this.btOrnek1.Click += new System.EventHandler(this.btOrnek1_Click);
            // 
            // btListeyiBosalt
            // 
            this.btListeyiBosalt.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btListeyiBosalt.Location = new System.Drawing.Point(769, 327);
            this.btListeyiBosalt.Name = "btListeyiBosalt";
            this.btListeyiBosalt.Size = new System.Drawing.Size(320, 57);
            this.btListeyiBosalt.TabIndex = 21;
            this.btListeyiBosalt.Text = "Listeyi Boşalt";
            this.btListeyiBosalt.UseVisualStyleBackColor = true;
            this.btListeyiBosalt.Click += new System.EventHandler(this.btListeyiBosalt_Click);
            // 
            // btOrnek2
            // 
            this.btOrnek2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btOrnek2.Location = new System.Drawing.Point(769, 78);
            this.btOrnek2.Name = "btOrnek2";
            this.btOrnek2.Size = new System.Drawing.Size(320, 57);
            this.btOrnek2.TabIndex = 22;
            this.btOrnek2.Text = "Örnek 2.";
            this.btOrnek2.UseVisualStyleBackColor = true;
            this.btOrnek2.Click += new System.EventHandler(this.btOrnek2_Click);
            // 
            // cbIsim
            // 
            this.cbIsim.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cbIsim.FormattingEnabled = true;
            this.cbIsim.Location = new System.Drawing.Point(35, 348);
            this.cbIsim.Name = "cbIsim";
            this.cbIsim.Size = new System.Drawing.Size(179, 39);
            this.cbIsim.TabIndex = 23;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(519, 300);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 31);
            this.label4.TabIndex = 26;
            this.label4.Text = "Numara";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(298, 300);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 31);
            this.label5.TabIndex = 25;
            this.label5.Text = "Soyisim";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(96, 300);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 31);
            this.label6.TabIndex = 24;
            this.label6.Text = "İsim";
            // 
            // cbSoyisim
            // 
            this.cbSoyisim.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cbSoyisim.FormattingEnabled = true;
            this.cbSoyisim.Location = new System.Drawing.Point(276, 348);
            this.cbSoyisim.Name = "cbSoyisim";
            this.cbSoyisim.Size = new System.Drawing.Size(179, 39);
            this.cbSoyisim.TabIndex = 27;
            // 
            // cbNumara
            // 
            this.cbNumara.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cbNumara.FormattingEnabled = true;
            this.cbNumara.Location = new System.Drawing.Point(497, 348);
            this.cbNumara.Name = "cbNumara";
            this.cbNumara.Size = new System.Drawing.Size(179, 39);
            this.cbNumara.TabIndex = 28;
            // 
            // fKomplexDataBinding
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1101, 606);
            this.Controls.Add(this.cbNumara);
            this.Controls.Add(this.cbSoyisim);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cbIsim);
            this.Controls.Add(this.btOrnek2);
            this.Controls.Add(this.btListeyiBosalt);
            this.Controls.Add(this.btOrnek1);
            this.Controls.Add(this.btKaydet);
            this.Controls.Add(this.lbListe);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbNumara);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbSoyisim);
            this.Controls.Add(this.tbIsim);
            this.Name = "fKomplexDataBinding";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "fKomplexDataBinding";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbSoyisim;
        private System.Windows.Forms.TextBox tbIsim;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbNumara;
        private System.Windows.Forms.ListBox lbListe;
        private System.Windows.Forms.Button btKaydet;
        private System.Windows.Forms.Button btOrnek1;
        private System.Windows.Forms.Button btListeyiBosalt;
        private System.Windows.Forms.Button btOrnek2;
        private System.Windows.Forms.ComboBox cbIsim;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbSoyisim;
        private System.Windows.Forms.ComboBox cbNumara;
    }
}
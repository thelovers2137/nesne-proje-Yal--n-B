﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uygulama
{
    public partial class fKomplexDataBinding : Form
    {
        public fKomplexDataBinding()
        {
            InitializeComponent();
        }
        class bilgiler
        {
            public string Isim { get; set; }
            public string Soyisim { get; set; }
            public string Numara { get; set; }
        }

    
        private void btKaydet_Click(object sender, EventArgs e)
        {
            bilgiler b = new bilgiler();
            b.Isim = tbIsim.Text;
            b.Soyisim = tbSoyisim.Text;
            b.Numara = tbNumara.Text;


            bagla(b);

        }

       void bagla(bilgiler b)
        {


            cbIsim.Items.Add(b.Isim);
            cbSoyisim.Items.Add(b.Soyisim);
            cbNumara.Items.Add(b.Numara);
        }



        #region Dizi ve list konusunda data bind
        private void btOrnek1_Click(object sender, EventArgs e)
        {
            string[] isimler = { "Zümra", "Efe", "Yalçın", "Yekta", "İsa" };

            lbListe.DataSource = isimler;
        }

        private void btListeyiBosalt_Click(object sender, EventArgs e)
        {
            lbListe.DataSource = null;
            lbListe.Items.Clear();
        }

        private void btOrnek2_Click(object sender, EventArgs e)
        {
            List<string> isimler = new List<string>();
            isimler.Add("Denizhan"); isimler.Add("Aleyna"); isimler.Add("Mustafa"); isimler.Add("Kerem"); isimler.Add("Zeynep");
            lbListe.DataSource = isimler;
        }
        #endregion




    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uygulama
{
    public partial class fMenuStripped : Form
    {
        public fMenuStripped()
        {
            InitializeComponent();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            fTarayici f = new fTarayici();
          
       //    this.Visible = false;
            f.Show();
        }

        private void form1ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            formList f = new formList();

  
            f.ShowDialog();

        }

        private void form2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fForm2 f = new fForm2(); 
            f.ShowDialog();
        }

        private void form3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fForm3 f = new fForm3();
            f.ShowDialog();

        }

        private void form4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fForm4 f = new fForm4();
            f.ShowDialog();

        }
    }
}

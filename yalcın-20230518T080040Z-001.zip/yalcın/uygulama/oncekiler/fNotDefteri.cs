﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uygulama
{
    public partial class fNotDefteri : Form
    {
        public fNotDefteri()
        {
            InitializeComponent();
        }

        private void çıkışToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult sonuc = MessageBox.Show("Çıkmak istediğinizden emin misiniz?", "UYARI", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (DialogResult.Yes == sonuc)
            {
                Application.Exit();
            }


        }

        private void tsmKaydet_Click(object sender, EventArgs e)
        {
            SaveFileDialog s = new SaveFileDialog();

            s.Filter = "Metin dosyası | *.txt";

            DialogResult sonuc = s.ShowDialog();

            if (DialogResult.OK == sonuc)
            {
                MessageBox.Show("Kaydetme işlemi başlıyor");
            }


        }

        private void açToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog o = new OpenFileDialog();

            o.Filter = "Metin dosyası |*.txt|Word dosyası |*.docx|Tüm dosyalar |*.*";


            DialogResult sonuc = o.ShowDialog();

            if (DialogResult.OK == sonuc)
            {
                //  MessageBox.Show("Dosya açma işlemi başlıyor");
                rtb1.LoadFile(o.FileName, RichTextBoxStreamType.PlainText);




            }

        }

        private void yazdırToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PrintDialog p = new PrintDialog();
            DialogResult sonuc = p.ShowDialog();
            if (sonuc==DialogResult.OK)
            {
                belge.Print();
            }

            
        }

        private void belge_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString(rtb1.Text, rtb1.Font, Brushes.Black, new Point(100, 100));
        }

        private void biçimToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog f = new FontDialog();

            if (f.ShowDialog()==DialogResult.OK)
            {
                rtb1.Font = f.Font;
            }
        }

        private void biçim2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog f = new ColorDialog();

            if (f.ShowDialog() == DialogResult.OK)
            {
                rtb1.SelectionColor = f.Color;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uygulama
{
    public partial class fTarayici : Form
    {
        public fTarayici()
        {
            InitializeComponent();
        }

        private void btAnasayfa_Click(object sender, EventArgs e)
        {
            try
            {
                wbTarayici.Navigate("http://www.google.com");
            }
            catch (Exception w)
            {
                MessageBox.Show(w.Message, "Çalışma hatası", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btGit_Click(object sender, EventArgs e)
        {
            wbTarayici.Navigate(tbAdres.Text);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uygulama
{
    public partial class fVeriMaskeleme : Form
    {
        public fVeriMaskeleme()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
        ErrorProvider ep = new ErrorProvider();
        private void textBox1_Validating(object sender, CancelEventArgs e)
        {
            if (textBox1.Text == "")
            {
                e.Cancel = true;
                ep.SetError(textBox1, "Adı ve soyadı giriniz.");
            }
            else
            {
                ep.SetError(textBox1, "");
            }
        }

        private void tb2_Validating(object sender, CancelEventArgs e)
        {
            int dersNotu;
            if (int.TryParse(tb2.Text, out dersNotu))
            {
                if (dersNotu < 0 || dersNotu > 100)
                {
                    e.Cancel = true;
                    ep.SetError(tb2, "0 - 100 arasında değer giriniz.");
                }
                else
                {
                    ep.SetError(tb2, "");
                }
            }
            else
            {
                e.Cancel = true;
                ep.SetError(tb2, "Sayısal değer giriniz.");
            }
        }
    }
}

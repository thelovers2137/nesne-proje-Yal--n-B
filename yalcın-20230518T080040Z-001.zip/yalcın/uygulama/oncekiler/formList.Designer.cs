﻿namespace uygulama
{
    partial class formList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.tbBilgi = new System.Windows.Forms.TextBox();
            this.btnATopla = new System.Windows.Forms.Button();
            this.lblLEkle = new System.Windows.Forms.Label();
            this.btnAYaz = new System.Windows.Forms.Button();
            this.lblLTopla = new System.Windows.Forms.Label();
            this.listeL = new System.Windows.Forms.ListBox();
            this.btnLBul = new System.Windows.Forms.Button();
            this.lblLYaz = new System.Windows.Forms.Label();
            this.lblLBul = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblLBul);
            this.groupBox1.Controls.Add(this.lblLYaz);
            this.groupBox1.Controls.Add(this.btnLBul);
            this.groupBox1.Controls.Add(this.listeL);
            this.groupBox1.Controls.Add(this.btnAYaz);
            this.groupBox1.Controls.Add(this.lblLTopla);
            this.groupBox1.Controls.Add(this.lblLEkle);
            this.groupBox1.Controls.Add(this.btnATopla);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.tbBilgi);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(645, 472);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Bilgiler";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(31, 50);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(161, 33);
            this.button1.TabIndex = 4;
            this.button1.Text = "Ekle";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tbBilgi
            // 
            this.tbBilgi.Location = new System.Drawing.Point(31, 19);
            this.tbBilgi.Multiline = true;
            this.tbBilgi.Name = "tbBilgi";
            this.tbBilgi.Size = new System.Drawing.Size(161, 25);
            this.tbBilgi.TabIndex = 0;
            // 
            // btnATopla
            // 
            this.btnATopla.Location = new System.Drawing.Point(198, 50);
            this.btnATopla.Name = "btnATopla";
            this.btnATopla.Size = new System.Drawing.Size(161, 33);
            this.btnATopla.TabIndex = 6;
            this.btnATopla.Text = "Topla";
            this.btnATopla.UseVisualStyleBackColor = true;
            this.btnATopla.Click += new System.EventHandler(this.btnATopla_Click);
            // 
            // lblLEkle
            // 
            this.lblLEkle.AutoSize = true;
            this.lblLEkle.Location = new System.Drawing.Point(28, 143);
            this.lblLEkle.Name = "lblLEkle";
            this.lblLEkle.Size = new System.Drawing.Size(35, 13);
            this.lblLEkle.TabIndex = 7;
            this.lblLEkle.Text = "label1";
            // 
            // btnAYaz
            // 
            this.btnAYaz.Location = new System.Drawing.Point(31, 89);
            this.btnAYaz.Name = "btnAYaz";
            this.btnAYaz.Size = new System.Drawing.Size(161, 33);
            this.btnAYaz.TabIndex = 8;
            this.btnAYaz.Text = "Yaz";
            this.btnAYaz.UseVisualStyleBackColor = true;
            this.btnAYaz.Click += new System.EventHandler(this.btnAYaz_Click);
            // 
            // lblLTopla
            // 
            this.lblLTopla.AutoSize = true;
            this.lblLTopla.Location = new System.Drawing.Point(28, 180);
            this.lblLTopla.Name = "lblLTopla";
            this.lblLTopla.Size = new System.Drawing.Size(35, 13);
            this.lblLTopla.TabIndex = 8;
            this.lblLTopla.Text = "label1";
            // 
            // listeL
            // 
            this.listeL.FormattingEnabled = true;
            this.listeL.Location = new System.Drawing.Point(31, 281);
            this.listeL.Name = "listeL";
            this.listeL.Size = new System.Drawing.Size(120, 95);
            this.listeL.TabIndex = 9;
            // 
            // btnLBul
            // 
            this.btnLBul.Location = new System.Drawing.Point(198, 89);
            this.btnLBul.Name = "btnLBul";
            this.btnLBul.Size = new System.Drawing.Size(161, 33);
            this.btnLBul.TabIndex = 9;
            this.btnLBul.Text = "Bul";
            this.btnLBul.UseVisualStyleBackColor = true;
            this.btnLBul.Click += new System.EventHandler(this.btnLBul_Click);
            // 
            // lblLYaz
            // 
            this.lblLYaz.AutoSize = true;
            this.lblLYaz.Location = new System.Drawing.Point(28, 217);
            this.lblLYaz.Name = "lblLYaz";
            this.lblLYaz.Size = new System.Drawing.Size(35, 13);
            this.lblLYaz.TabIndex = 10;
            this.lblLYaz.Text = "label1";
            // 
            // lblLBul
            // 
            this.lblLBul.AutoSize = true;
            this.lblLBul.Location = new System.Drawing.Point(28, 247);
            this.lblLBul.Name = "lblLBul";
            this.lblLBul.Size = new System.Drawing.Size(35, 13);
            this.lblLBul.TabIndex = 11;
            this.lblLBul.Text = "label1";
            // 
            // formList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(749, 554);
            this.Controls.Add(this.groupBox1);
            this.Name = "formList";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "formList";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tbBilgi;
        private System.Windows.Forms.Button btnATopla;
        private System.Windows.Forms.Label lblLEkle;
        private System.Windows.Forms.Button btnAYaz;
        private System.Windows.Forms.Label lblLTopla;
        private System.Windows.Forms.Button btnLBul;
        private System.Windows.Forms.ListBox listeL;
        private System.Windows.Forms.Label lblLYaz;
        private System.Windows.Forms.Label lblLBul;
    }
}
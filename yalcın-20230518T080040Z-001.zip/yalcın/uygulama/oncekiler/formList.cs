﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace uygulama
{
    public partial class formList : Form
    {
        public formList()
        {
            InitializeComponent();
        }
 


        List<int> kolL = new List<int>(); // List koleksiyonu
        Stopwatch km = new Stopwatch(); // Geçen süreyi hesaplama için        nesne
        int elemanSayisi = 100000; // Test için eleman sayısı


        private void button1_Click(object sender, EventArgs e)
        {
            
                km.Start();
                for (int i = 0; i < elemanSayisi; i++)
                {
                    kolL.Add(i);
                }
                km.Stop();
                lblLEkle.Text ="= " + km.Elapsed.TotalMilliseconds;
                km.Reset();
            }

        private void btnATopla_Click(object sender, EventArgs e)
        {
            km.Start();
            int toplam = 0;
            for (int i = 0; i < kolL.Count; i++)
            {
                toplam += kolL[i];
            }
            km.Stop();
            lblLTopla.Text = "= " +  km.Elapsed.TotalMilliseconds;
            km.Reset();
        }

        private void btnAYaz_Click(object sender, EventArgs e)
        {
            km.Start();
            for (int i = 0; i < kolL.Count; i++)
            {
                listeL.Items.Add(kolL[i]);
            }
            km.Stop();
            lblLYaz.Text = "= " + km.Elapsed.TotalMilliseconds;
            km.Reset();
        }

        private void btnLBul_Click(object sender, EventArgs e)
        {
            km.Start();
            if (kolL.Contains(9999))
            {
                km.Stop();
            }
            lblLBul.Text = "= " + km.Elapsed.TotalMilliseconds;
            km.Reset();
        }
    }
}

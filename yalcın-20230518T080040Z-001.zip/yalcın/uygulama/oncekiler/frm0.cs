﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uygulama
{
    public partial class frm0 : Form
    {
        public frm0()
        {
            InitializeComponent();
        }
        int toplam = 0; int gecici;
        private void button1_Click(object sender, EventArgs e)
        {
            topla();
        }


        private void topla()
        {
               gecici = Convert.ToInt16(textBox1.Text);
               
                    if (gecici == 0)
                    {
                     
                        Application.Exit();
                    }
                    else
                    {
                        toplam += gecici;
                        label1.Text = toplam.ToString();
                 
                    }
            
        }

    }
}

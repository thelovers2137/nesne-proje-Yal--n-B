﻿namespace uygulama
{
    partial class frmDizi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btTanimlama1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btInt = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.tbBilgi = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lbToplam = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbOrtalamasi = new System.Windows.Forms.Label();
            this.lbSayilar = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btMatematik = new System.Windows.Forms.Button();
            this.tbSayi = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btEkleRandom = new System.Windows.Forms.Button();
            this.tbRandomAdet = new System.Windows.Forms.TextBox();
            this.tbRandom = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lbEnKucuk = new System.Windows.Forms.Label();
            this.lbIlkDeger = new System.Windows.Forms.Label();
            this.lbSonDeger = new System.Windows.Forms.Label();
            this.lbToplami2 = new System.Windows.Forms.Label();
            this.lbBoyutBilgisi = new System.Windows.Forms.Label();
            this.lbOrtalamasi2 = new System.Windows.Forms.Label();
            this.lbEnBuyuk = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // btTanimlama1
            // 
            this.btTanimlama1.Location = new System.Drawing.Point(3, 12);
            this.btTanimlama1.Name = "btTanimlama1";
            this.btTanimlama1.Size = new System.Drawing.Size(108, 65);
            this.btTanimlama1.TabIndex = 0;
            this.btTanimlama1.Text = "Tanımlama 1";
            this.btTanimlama1.UseVisualStyleBackColor = true;
            this.btTanimlama1.Click += new System.EventHandler(this.btTanimlama1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(280, 68);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(8, 8);
            this.button2.TabIndex = 1;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // btInt
            // 
            this.btInt.Location = new System.Drawing.Point(117, 12);
            this.btInt.Name = "btInt";
            this.btInt.Size = new System.Drawing.Size(108, 65);
            this.btInt.TabIndex = 2;
            this.btInt.Text = "Int tanımlama";
            this.btInt.UseVisualStyleBackColor = true;
            this.btInt.Click += new System.EventHandler(this.btInt_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.tbBilgi);
            this.groupBox1.Location = new System.Drawing.Point(29, 93);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(182, 105);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Bilgiler";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(31, 50);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(105, 33);
            this.button1.TabIndex = 4;
            this.button1.Text = "Ekle";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tbBilgi
            // 
            this.tbBilgi.Location = new System.Drawing.Point(31, 19);
            this.tbBilgi.Multiline = true;
            this.tbBilgi.Name = "tbBilgi";
            this.tbBilgi.Size = new System.Drawing.Size(105, 25);
            this.tbBilgi.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lbToplam);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.lbOrtalamasi);
            this.groupBox2.Controls.Add(this.lbSayilar);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.btMatematik);
            this.groupBox2.Controls.Add(this.tbSayi);
            this.groupBox2.Location = new System.Drawing.Point(256, 16);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(322, 167);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Matematik işlemi";
            // 
            // lbToplam
            // 
            this.lbToplam.AutoSize = true;
            this.lbToplam.Location = new System.Drawing.Point(72, 141);
            this.lbToplam.Name = "lbToplam";
            this.lbToplam.Size = new System.Drawing.Size(0, 13);
            this.lbToplam.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 141);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Toplamı:";
            // 
            // lbOrtalamasi
            // 
            this.lbOrtalamasi.AutoSize = true;
            this.lbOrtalamasi.Location = new System.Drawing.Point(72, 117);
            this.lbOrtalamasi.Name = "lbOrtalamasi";
            this.lbOrtalamasi.Size = new System.Drawing.Size(0, 13);
            this.lbOrtalamasi.TabIndex = 8;
            // 
            // lbSayilar
            // 
            this.lbSayilar.AutoSize = true;
            this.lbSayilar.Location = new System.Drawing.Point(72, 92);
            this.lbSayilar.Name = "lbSayilar";
            this.lbSayilar.Size = new System.Drawing.Size(0, 13);
            this.lbSayilar.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Ortalaması:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Sayılar:";
            // 
            // btMatematik
            // 
            this.btMatematik.Location = new System.Drawing.Point(31, 50);
            this.btMatematik.Name = "btMatematik";
            this.btMatematik.Size = new System.Drawing.Size(105, 33);
            this.btMatematik.TabIndex = 4;
            this.btMatematik.Text = "Ekle";
            this.btMatematik.UseVisualStyleBackColor = true;
            this.btMatematik.Click += new System.EventHandler(this.btMatematik_Click);
            // 
            // tbSayi
            // 
            this.tbSayi.Location = new System.Drawing.Point(31, 19);
            this.tbSayi.Multiline = true;
            this.tbSayi.Name = "tbSayi";
            this.tbSayi.Size = new System.Drawing.Size(105, 25);
            this.tbSayi.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lbEnBuyuk);
            this.groupBox3.Controls.Add(this.lbOrtalamasi2);
            this.groupBox3.Controls.Add(this.lbBoyutBilgisi);
            this.groupBox3.Controls.Add(this.lbToplami2);
            this.groupBox3.Controls.Add(this.lbSonDeger);
            this.groupBox3.Controls.Add(this.lbIlkDeger);
            this.groupBox3.Controls.Add(this.lbEnKucuk);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.tbRandom);
            this.groupBox3.Controls.Add(this.btEkleRandom);
            this.groupBox3.Controls.Add(this.tbRandomAdet);
            this.groupBox3.Location = new System.Drawing.Point(606, 32);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(255, 346);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Foreach Kullanımı";
            // 
            // btEkleRandom
            // 
            this.btEkleRandom.Location = new System.Drawing.Point(31, 50);
            this.btEkleRandom.Name = "btEkleRandom";
            this.btEkleRandom.Size = new System.Drawing.Size(187, 33);
            this.btEkleRandom.TabIndex = 4;
            this.btEkleRandom.Text = "Ekle";
            this.btEkleRandom.UseVisualStyleBackColor = true;
            this.btEkleRandom.Click += new System.EventHandler(this.btEkleRandom_Click);
            // 
            // tbRandomAdet
            // 
            this.tbRandomAdet.Location = new System.Drawing.Point(31, 19);
            this.tbRandomAdet.Multiline = true;
            this.tbRandomAdet.Name = "tbRandomAdet";
            this.tbRandomAdet.Size = new System.Drawing.Size(119, 25);
            this.tbRandomAdet.TabIndex = 0;
            // 
            // tbRandom
            // 
            this.tbRandom.Location = new System.Drawing.Point(31, 89);
            this.tbRandom.Multiline = true;
            this.tbRandom.Name = "tbRandom";
            this.tbRandom.ReadOnly = true;
            this.tbRandom.Size = new System.Drawing.Size(187, 25);
            this.tbRandom.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 131);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "En küçük değer:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 176);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Ortalaması:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 153);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "En büyük değer:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 200);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "İlk değer:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 223);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Son değer:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 249);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(47, 13);
            this.label9.TabIndex = 16;
            this.label9.Text = "Toplamı:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 272);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 13);
            this.label10.TabIndex = 17;
            this.label10.Text = "Boyut bilgisi:";
            // 
            // lbEnKucuk
            // 
            this.lbEnKucuk.AutoSize = true;
            this.lbEnKucuk.Location = new System.Drawing.Point(97, 131);
            this.lbEnKucuk.Name = "lbEnKucuk";
            this.lbEnKucuk.Size = new System.Drawing.Size(86, 13);
            this.lbEnKucuk.TabIndex = 18;
            this.lbEnKucuk.Text = "En küçük değer:";
            // 
            // lbIlkDeger
            // 
            this.lbIlkDeger.AutoSize = true;
            this.lbIlkDeger.Location = new System.Drawing.Point(97, 200);
            this.lbIlkDeger.Name = "lbIlkDeger";
            this.lbIlkDeger.Size = new System.Drawing.Size(47, 13);
            this.lbIlkDeger.TabIndex = 19;
            this.lbIlkDeger.Text = "ilk değer";
            // 
            // lbSonDeger
            // 
            this.lbSonDeger.AutoSize = true;
            this.lbSonDeger.Location = new System.Drawing.Point(97, 223);
            this.lbSonDeger.Name = "lbSonDeger";
            this.lbSonDeger.Size = new System.Drawing.Size(54, 13);
            this.lbSonDeger.TabIndex = 20;
            this.lbSonDeger.Text = "son değer";
            // 
            // lbToplami2
            // 
            this.lbToplami2.AutoSize = true;
            this.lbToplami2.Location = new System.Drawing.Point(97, 249);
            this.lbToplami2.Name = "lbToplami2";
            this.lbToplami2.Size = new System.Drawing.Size(40, 13);
            this.lbToplami2.TabIndex = 21;
            this.lbToplami2.Text = "toplamı";
            // 
            // lbBoyutBilgisi
            // 
            this.lbBoyutBilgisi.AutoSize = true;
            this.lbBoyutBilgisi.Location = new System.Drawing.Point(97, 272);
            this.lbBoyutBilgisi.Name = "lbBoyutBilgisi";
            this.lbBoyutBilgisi.Size = new System.Drawing.Size(61, 13);
            this.lbBoyutBilgisi.TabIndex = 22;
            this.lbBoyutBilgisi.Text = "boyut bilgisi";
            // 
            // lbOrtalamasi2
            // 
            this.lbOrtalamasi2.AutoSize = true;
            this.lbOrtalamasi2.Location = new System.Drawing.Point(97, 176);
            this.lbOrtalamasi2.Name = "lbOrtalamasi2";
            this.lbOrtalamasi2.Size = new System.Drawing.Size(54, 13);
            this.lbOrtalamasi2.TabIndex = 23;
            this.lbOrtalamasi2.Text = "ortalaması";
            // 
            // lbEnBuyuk
            // 
            this.lbEnBuyuk.AutoSize = true;
            this.lbEnBuyuk.Location = new System.Drawing.Point(97, 154);
            this.lbEnBuyuk.Name = "lbEnBuyuk";
            this.lbEnBuyuk.Size = new System.Drawing.Size(55, 13);
            this.lbEnBuyuk.TabIndex = 24;
            this.lbEnBuyuk.Text = "En büyük,";
            // 
            // frmDizi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(873, 335);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btInt);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btTanimlama1);
            this.Name = "frmDizi";
            this.Text = "frmDizi";
            this.Load += new System.EventHandler(this.frmDizi_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btTanimlama1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btInt;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tbBilgi;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btMatematik;
        private System.Windows.Forms.TextBox tbSayi;
        private System.Windows.Forms.Label lbOrtalamasi;
        private System.Windows.Forms.Label lbSayilar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbToplam;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox tbRandom;
        private System.Windows.Forms.Button btEkleRandom;
        private System.Windows.Forms.TextBox tbRandomAdet;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbEnBuyuk;
        private System.Windows.Forms.Label lbOrtalamasi2;
        private System.Windows.Forms.Label lbBoyutBilgisi;
        private System.Windows.Forms.Label lbToplami2;
        private System.Windows.Forms.Label lbSonDeger;
        private System.Windows.Forms.Label lbIlkDeger;
        private System.Windows.Forms.Label lbEnKucuk;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
    }
}
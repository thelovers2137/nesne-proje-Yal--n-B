﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uygulama
{
    public partial class frmDizi : Form
    {
        public frmDizi()
        {
            InitializeComponent();
        }

        private void frmDizi_Load(object sender, EventArgs e)
        {

        }

        private void btTanimlama1_Click(object sender, EventArgs e)
        {
         /*   string isim = "Zümra";
            isim = "Denizhan";
            isim = "İsa";
*/

            string[] isim = new string[9];

            isim[0] = "Denizhan";
            isim[1] = "Efe";
            isim[3] = "Gamzenur";
            isim[2] = "Zümra";
            isim[4] = "Yalçın";
            isim[5] = "Mustafa";
            isim[6] = "İsa";
            isim[7] = "Kerem";
            isim[8] = "Yekta";


        }

        private void btInt_Click(object sender, EventArgs e)
        {
            int[] sayilar = new int[6];
            sayilar[0] = 10; //sayilar dizisinin 0 index numaralı elemanı 10 oldu.
            sayilar[1] = 25; //sayilar dizisinin 1 index numaralı elemanı 25 oldu.
            sayilar[2] = 45; //sayilar dizisinin 2 index numaralı elemanı 45 oldu.
            sayilar[3] = 5; //sayilar dizisinin 3 index numaralı elemanı 5 oldu.
            sayilar[4] = -30; //sayilar dizisinin 4 index numaralı elemanı -30 oldu.
            sayilar[5] = -50; //sayilar dizisinin 5 index numaralı elemanı -50 oldu
        }

        string[] deger = new string[10];
        int sayac = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            deger[sayac] = tbBilgi.Text;
            sayac++;
            this.Text = "";

            for (int i = 0; i < sayac; i++)
            {
                this.Text += " " + deger[i]; 
            }


        }

        int[] sayim = new int[10];
        private void btMatematik_Click(object sender, EventArgs e)
        {
         int   toplam = 0;
            sayim[sayac] = Convert.ToInt16(tbSayi.Text);
            sayac++;
            lbSayilar.Text = "";
            this.Text = "";
            for (int i = 0; i < sayac; i++)
            {
                this.Text += " " + sayim[i];
                lbSayilar.Text += " " + sayim[i];
                toplam += sayim[i];
            }

            lbToplam.Text = toplam.ToString();
            lbOrtalamasi.Text = (toplam / sayac).ToString();

        }

        private void btEkleRandom_Click(object sender, EventArgs e)
        {
            try
            {
                Random r = new Random();

                int adet = Convert.ToInt16(tbRandomAdet.Text);

                int[] sayi = new int[adet];

                for (int i = 0; i < adet; i++)
                {
                    sayi[i] = r.Next(0, 100);
                }

                tbRandom.Text = "";
                foreach (var item in sayi)
                {
                    tbRandom.Text = tbRandom.Text + " " + item;
 
                }

                Istatistik(sayi);
            }
            catch (Exception w)
            {
                MessageBox.Show(w.Message.ToString());
            }
        }

        void Istatistik(int[] sayi)
        {
            try
            {
                lbEnBuyuk.Text = sayi.Max().ToString();
                lbEnKucuk.Text = sayi.Min().ToString();
                lbIlkDeger.Text = sayi.First().ToString();
                lbOrtalamasi2.Text = sayi.Average().ToString();
                lbIlkDeger.Text = sayi.First().ToString();
                lbSonDeger.Text = sayi.Last().ToString();
                lbToplami2.Text = sayi.Sum().ToString();
                lbBoyutBilgisi.Text = sayi.Rank.ToString();


            }
            catch (Exception w)
            {

                MessageBox.Show(w.Message.ToString());
            }
        }







    }
}

﻿namespace uygulama
{
    partial class frmDizi2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.tbBilgi = new System.Windows.Forms.TextBox();
            this.rtSonuc = new System.Windows.Forms.RichTextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btNotEkle = new System.Windows.Forms.Button();
            this.tbn1 = new System.Windows.Forms.TextBox();
            this.tbn2 = new System.Windows.Forms.TextBox();
            this.tbn4 = new System.Windows.Forms.TextBox();
            this.tbn3 = new System.Windows.Forms.TextBox();
            this.rtNotlar = new System.Windows.Forms.RichTextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rtSonuc);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.tbBilgi);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(229, 222);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Bilgiler";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(31, 50);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(161, 33);
            this.button1.TabIndex = 4;
            this.button1.Text = "Ekle";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tbBilgi
            // 
            this.tbBilgi.Location = new System.Drawing.Point(31, 19);
            this.tbBilgi.Multiline = true;
            this.tbBilgi.Name = "tbBilgi";
            this.tbBilgi.Size = new System.Drawing.Size(161, 25);
            this.tbBilgi.TabIndex = 0;
            // 
            // rtSonuc
            // 
            this.rtSonuc.Location = new System.Drawing.Point(31, 90);
            this.rtSonuc.Name = "rtSonuc";
            this.rtSonuc.Size = new System.Drawing.Size(161, 108);
            this.rtSonuc.TabIndex = 5;
            this.rtSonuc.Text = "";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rtNotlar);
            this.groupBox2.Controls.Add(this.tbn3);
            this.groupBox2.Controls.Add(this.tbn4);
            this.groupBox2.Controls.Add(this.tbn2);
            this.groupBox2.Controls.Add(this.tbn1);
            this.groupBox2.Controls.Add(this.btNotEkle);
            this.groupBox2.Location = new System.Drawing.Point(259, 22);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(355, 331);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Not Bilgisi";
            // 
            // btNotEkle
            // 
            this.btNotEkle.Location = new System.Drawing.Point(31, 55);
            this.btNotEkle.Name = "btNotEkle";
            this.btNotEkle.Size = new System.Drawing.Size(186, 33);
            this.btNotEkle.TabIndex = 4;
            this.btNotEkle.Text = "Ekle";
            this.btNotEkle.UseVisualStyleBackColor = true;
            this.btNotEkle.Click += new System.EventHandler(this.btNotEkle_Click);
            // 
            // tbn1
            // 
            this.tbn1.Location = new System.Drawing.Point(31, 19);
            this.tbn1.Multiline = true;
            this.tbn1.Name = "tbn1";
            this.tbn1.Size = new System.Drawing.Size(42, 30);
            this.tbn1.TabIndex = 0;
            // 
            // tbn2
            // 
            this.tbn2.Location = new System.Drawing.Point(79, 19);
            this.tbn2.Multiline = true;
            this.tbn2.Name = "tbn2";
            this.tbn2.Size = new System.Drawing.Size(42, 30);
            this.tbn2.TabIndex = 5;
            // 
            // tbn4
            // 
            this.tbn4.Location = new System.Drawing.Point(175, 19);
            this.tbn4.Multiline = true;
            this.tbn4.Name = "tbn4";
            this.tbn4.Size = new System.Drawing.Size(42, 30);
            this.tbn4.TabIndex = 6;
            // 
            // tbn3
            // 
            this.tbn3.Location = new System.Drawing.Point(127, 19);
            this.tbn3.Multiline = true;
            this.tbn3.Name = "tbn3";
            this.tbn3.Size = new System.Drawing.Size(42, 30);
            this.tbn3.TabIndex = 7;
            // 
            // rtNotlar
            // 
            this.rtNotlar.Location = new System.Drawing.Point(31, 94);
            this.rtNotlar.Name = "rtNotlar";
            this.rtNotlar.Size = new System.Drawing.Size(186, 108);
            this.rtNotlar.TabIndex = 6;
            this.rtNotlar.Text = "";
            // 
            // frmDizi2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(996, 441);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmDizi2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmDizi2";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tbBilgi;
        private System.Windows.Forms.RichTextBox rtSonuc;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RichTextBox rtNotlar;
        private System.Windows.Forms.TextBox tbn3;
        private System.Windows.Forms.TextBox tbn4;
        private System.Windows.Forms.TextBox tbn2;
        private System.Windows.Forms.TextBox tbn1;
        private System.Windows.Forms.Button btNotEkle;
    }
}
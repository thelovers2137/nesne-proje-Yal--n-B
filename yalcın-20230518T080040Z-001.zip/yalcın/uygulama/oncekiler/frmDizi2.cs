﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uygulama
{
    public partial class frmDizi2 : Form
    {
        public frmDizi2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[,] sayilar = new int[3, 4];
            sayilar[0, 0] = 45;
            sayilar[0, 1] = 55;
            sayilar[0, 2] = 60;
            sayilar[0, 3] = 65;
            sayilar[1, 0] = 75;
            sayilar[1, 1] = 80;
            sayilar[1, 2] = 85;
            sayilar[1, 3] = 90;
            sayilar[2, 0] = 10;
            sayilar[2, 1] = 20;
            sayilar[2, 2] = 30;
            sayilar[2, 3] = 40;

            rtSonuc.Text = "";
            for (int j = 0; j < 3; j++)
            {
                for (int i = 0; i < 4; i++)
                {
                    rtSonuc.Text = rtSonuc.Text + sayilar[j, i] + " ";
                }

                rtSonuc.Text = rtSonuc.Text + "\n";
            }

        }
        int[,] notlar = new int[9, 4];
        int sayac = 0;
        private void btNotEkle_Click(object sender, EventArgs e)
        {


            notlar[sayac, 0] = Convert.ToInt16(tbn1.Text);
            notlar[sayac, 1] = Convert.ToInt16(tbn2.Text);
            notlar[sayac, 2] = Convert.ToInt16(tbn3.Text);
            notlar[sayac, 3] = Convert.ToInt16(tbn4.Text);

            rtNotlar.Text = rtNotlar.Text
                + notlar[sayac, 0] + " "
                + notlar[sayac, 1] + " "
                + notlar[sayac, 2] + " "
                + notlar[sayac, 3] + " ";
            rtNotlar.Text += "\n";
            tbn1.Text = null;
             tbn2.Text = null;
            tbn3.Text = null;
            tbn4.Text = null;

        }
    }
}

﻿namespace uygulama
{
    partial class frmForm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmForm1));
            this.btKaydet = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btIptal = new System.Windows.Forms.Button();
            this.btnKapat = new System.Windows.Forms.Button();
            this.btnYaziyiDegistir = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btKaydet
            // 
            this.btKaydet.Location = new System.Drawing.Point(101, 114);
            this.btKaydet.Name = "btKaydet";
            this.btKaydet.Size = new System.Drawing.Size(75, 23);
            this.btKaydet.TabIndex = 2;
            this.btKaydet.Text = "Kaydet";
            this.btKaydet.UseVisualStyleBackColor = true;
            this.btKaydet.Click += new System.EventHandler(this.btKaydet_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(101, 88);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(156, 20);
            this.textBox1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(101, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Bilgileriniz";
            // 
            // btIptal
            // 
            this.btIptal.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btIptal.Location = new System.Drawing.Point(182, 114);
            this.btIptal.Name = "btIptal";
            this.btIptal.Size = new System.Drawing.Size(75, 23);
            this.btIptal.TabIndex = 3;
            this.btIptal.Text = "İptal";
            this.btIptal.UseVisualStyleBackColor = true;
            this.btIptal.Click += new System.EventHandler(this.btIptal_Click);
            // 
            // btnKapat
            // 
            this.btnKapat.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnKapat.Location = new System.Drawing.Point(263, 114);
            this.btnKapat.Name = "btnKapat";
            this.btnKapat.Size = new System.Drawing.Size(75, 23);
            this.btnKapat.TabIndex = 4;
            this.btnKapat.Text = "Kapat";
            this.btnKapat.UseVisualStyleBackColor = true;
            this.btnKapat.Click += new System.EventHandler(this.btnKapat_Click);
            // 
            // btnYaziyiDegistir
            // 
            this.btnYaziyiDegistir.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnYaziyiDegistir.Location = new System.Drawing.Point(182, 158);
            this.btnYaziyiDegistir.Name = "btnYaziyiDegistir";
            this.btnYaziyiDegistir.Size = new System.Drawing.Size(104, 34);
            this.btnYaziyiDegistir.TabIndex = 5;
            this.btnYaziyiDegistir.Text = "Yazıyı değiştir";
            this.btnYaziyiDegistir.UseVisualStyleBackColor = true;
            this.btnYaziyiDegistir.Click += new System.EventHandler(this.btnYaziyiDegistir_Click);
            // 
            // frmForm1
            // 
            this.AcceptButton = this.btKaydet;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::uygulama.Properties.Resources._3;
            this.CancelButton = this.btIptal;
            this.ClientSize = new System.Drawing.Size(368, 227);
            this.Controls.Add(this.btnYaziyiDegistir);
            this.Controls.Add(this.btnKapat);
            this.Controls.Add(this.btIptal);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btKaydet);
            this.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmForm1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmForm1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmForm1_FormClosing);
            this.Load += new System.EventHandler(this.frmForm1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btKaydet;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btIptal;
        private System.Windows.Forms.Button btnKapat;
        private System.Windows.Forms.Button btnYaziyiDegistir;
    }
}
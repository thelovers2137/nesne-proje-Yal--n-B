﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uygulama
{
    public partial class frmForm1 : Form
    {
        public frmForm1()
        {
            InitializeComponent();
        }


        private void esc()
        { MessageBox.Show("ESC'ye basıldı"); }
        private void enter()
        { MessageBox.Show("Enter'e basıldı"); }

        private void btKaydet_Click(object sender, EventArgs e)
        {
            enter();
        }

        private void btIptal_Click(object sender, EventArgs e)
        {

            esc();
        }

        private void frmForm1_Load(object sender, EventArgs e)
        {
            //   this.Visible = false;
        //    MessageBox.Show("Form açılıyor");
        }

        private void frmForm1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //         MessageBox.Show("Form kapanıyor");

        }

        private void btnKapat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnYaziyiDegistir_Click(object sender, EventArgs e)
        {
            this.Text = "Tosya-Ortahisar";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uygulama
{
    public partial class frmTekCiftO : Form
    {
        public frmTekCiftO()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int sayi = Convert.ToInt16(textBox1.Text);
            MessageBox.Show(TekMiCiftMi(sayi).ToString());
        }

        private bool TekMiCiftMi(int kontrol)
        {
            try
            {
                if (kontrol % 2 != 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }

 
            }
            catch  
            {
 
                return false;
                throw;
            }
        }
    }
}
